<?php
	$con=mysqli_connect('localhost','root','','tienda de abarrotes pagina web');